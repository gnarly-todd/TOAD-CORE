//! Tiny HTTP/1.1 server for the web UI opened in the PS5 browser (Connection: close, no keep-alive).
//! Routes: DESIGN.md "Web API".
use crate::config::{self, Settings};
use crate::scan::{Kind, Packing, Source};
use crate::{cache, register, storage, sys};
use std::collections::HashSet;
use std::fs;
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::{Component, Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Condvar, Mutex};
use std::time::Duration;

pub const PORT: u16 = 8097;
const MAX_REQUEST: usize = 16 << 10;
const LOG_LINES: usize = 100;
const UI: &str = include_str!("ui.html");
const APP_ICON: &[u8] = include_bytes!("../ps5/icon0.png");

#[derive(Clone)]
pub struct Game {
    pub src: Source,
    /// "pending" | "checking" | "building" | "ready" | "error" | "duplicate"
    pub status: &'static str,
    pub error: Option<String>,
    pub cache_size: u64,
    pub cache_built: Option<u64>,
}

pub struct State {
    /// The last scan: library games first, then duplicates.
    pub games: Mutex<Vec<Game>>,
    pub settings: Mutex<Settings>,
    /// Title ids to rebuild on the next scan.
    pub forced: Mutex<HashSet<String>>,
    /// Purge requested: done by the scan loop, so it never races a build.
    pub purge: AtomicBool,
    pub busy: AtomicBool,
    /// Start-up is waiting for this ("kstuff" or "shadowmount", main::wait_ready); None once ready.
    pub waiting: Mutex<Option<&'static str>>,
    /// Held by the scan loop for a whole pass (scan, purge, build, register); delete takes it.
    pub work: Mutex<()>,
    pub low_space: AtomicBool,
    pub cache_total: Mutex<u64>,
    /// Title ids registered by this run or with a built cache; launch::watch overlays only these.
    pub titles: Arc<Mutex<HashSet<String>>>,
    /// Title ids with a live game session (launch::watch); the scan loop pauses while non-empty.
    pub running: Arc<Mutex<HashSet<String>>>,
    rescan: Mutex<bool>,
    wake: Condvar,
}

impl State {
    pub fn new(settings: Settings) -> State {
        State {
            games: Mutex::new(Vec::new()),
            settings: Mutex::new(settings),
            forced: Mutex::new(HashSet::new()),
            purge: AtomicBool::new(false),
            busy: AtomicBool::new(false),
            waiting: Mutex::new(None),
            work: Mutex::new(()),
            low_space: AtomicBool::new(false),
            cache_total: Mutex::new(0),
            titles: Arc::new(Mutex::new(HashSet::new())),
            running: Arc::new(Mutex::new(HashSet::new())),
            rescan: Mutex::new(false),
            wake: Condvar::new(),
        }
    }

    /// Updates the entry of the source at `path` (if still listed).
    pub fn update(&self, path: &Path, f: impl FnOnce(&mut Game)) {
        if let Some(g) = self.games.lock().unwrap().iter_mut().find(|g| g.src.path == path) {
            f(g);
        }
    }

    /// Wakes the scan loop now.
    pub fn wake(&self) {
        *self.rescan.lock().unwrap() = true;
        self.wake.notify_all();
    }

    /// Blocks until `wake` or `timeout`, then clears the flag.
    pub fn wait(&self, timeout: Duration) {
        let flag = self.rescan.lock().unwrap();
        let (mut flag, _) = self.wake.wait_timeout_while(flag, timeout, |f| !*f).unwrap();
        *flag = false;
    }

    /// A game runs: no scan/build/register/purge until it exits (requests stay queued).
    pub fn paused(&self) -> bool {
        !self.running.lock().unwrap().is_empty()
    }

    /// Title ids of the library (duplicates excluded).
    pub fn library(&self) -> Vec<String> {
        let games = self.games.lock().unwrap();
        games.iter().filter(|g| g.status != "duplicate").map(|g| g.src.title_id.clone()).collect()
    }

    fn source(&self, tid: &str) -> Option<Source> {
        let games = self.games.lock().unwrap();
        games.iter().find(|g| g.src.title_id == tid && g.status != "duplicate").map(|g| g.src.clone())
    }
}

/// `playgo_off`: the setting's title ids; None while add_emulators is off (no stub at all, so the
/// UI shows no switch).
fn game_json(g: &Game, playgo_off: Option<&[String]>, crash: Option<&crate::crash::Crash>) -> serde_json::Value {
    let (kind, packing) = match g.src.kind {
        Kind::Pkg => ("pkg", None),
        Kind::Folder(Packing::Plain) => ("folder", Some("plain")),
        Kind::Folder(Packing::Zstd) => ("folder", Some("zstd")),
        Kind::Folder(Packing::Lz4) => ("folder", Some("lz4")),
    };
    serde_json::json!({
        "title_id": g.src.title_id,
        "title_name": g.src.title_name,
        "version": g.src.version,
        "path": g.src.path.to_string_lossy(),
        "kind": kind,
        "packing": packing,
        "drive": g.src.drive,
        "size": g.src.size,
        "status": g.status,
        "error": g.error,
        "cache_size": g.cache_size,
        "cache_built": g.cache_built,
        "backport": g.src.backport.as_ref().map(|b| b.to_string_lossy()),
        // ponytail: reads the game's .ampr on every state poll (a few hundred bytes per game).
        "playgo": playgo_off.and_then(|_| crate::cache::playgo_import(&g.src.title_id)),
        "playgo_off": playgo_off.is_some_and(|l| l.iter().any(|t| *t == g.src.title_id)),
        "crash": crash.map(|c| serde_json::json!({"at": c.at, "process": c.process, "status": c.status})),
    })
}

/// Single instance: binds PORT, asking an older copy on it to quit first (POST /api/quit),
/// retrying for 5 s. None: the port stays taken (an older build without /api/quit, or another
/// app), so this copy must not run.
pub fn take_port() -> Option<TcpListener> {
    if let Ok(l) = TcpListener::bind(("0.0.0.0", PORT)) {
        return Some(l);
    }
    for _ in 0..20 {
        // Asked again each try: the older copy refuses while a scan pass (a build) runs.
        if let Ok(mut s) = TcpStream::connect(("127.0.0.1", PORT)) {
            let _ = s.write_all(b"POST /api/quit HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Length: 0\r\n\r\n");
        }
        std::thread::sleep(Duration::from_millis(250));
        if let Ok(l) = TcpListener::bind(("0.0.0.0", PORT)) {
            return Some(l);
        }
    }
    None
}

/// Listens on 0.0.0.0:PORT forever, one short-lived thread per connection. Once bound, registers
/// the home-screen tile that opens the UI (once, in its own thread).
pub fn serve(state: Arc<State>, mut listener: TcpListener) {
    log!("web UI on port {PORT}");
    std::thread::spawn(|| crate::register::register_tile(PORT));
    loop {
        match listener.accept() {
            Ok((conn, _)) => {
                let state = state.clone();
                std::thread::spawn(move || {
                    let _ = handle(&state, conn);
                });
            }
            Err(e) => {
                // Rest mode can close the listening socket (#110: after a wake the UI was gone and a
                // second copy could bind the port). ponytail: any accept error rebinds (a transient one
                // only drops the backlog); a dead socket whose accept blocks without an error is not seen.
                log!("web: accept on port {PORT} failed: {e}; binding it again");
                drop(listener);
                listener = rebind(&state);
                log!("web UI on port {PORT} again");
            }
        }
    }
}

/// Binds PORT again, retrying every second. A newer copy that took the port meanwhile wins: this
/// one quits, unless a game runs (its overlay would stay mounted; /api/quit refuses then too).
fn rebind(state: &State) -> TcpListener {
    let mut logged = false;
    loop {
        std::thread::sleep(Duration::from_secs(1));
        match TcpListener::bind(("0.0.0.0", PORT)) {
            Ok(l) => return l,
            Err(e) if e.kind() == std::io::ErrorKind::AddrInUse && !state.paused() => {
                log!("web: port {PORT} taken by another copy; quitting");
                std::process::exit(0)
            }
            Err(e) if !logged => {
                logged = true;
                log!("web: bind port {PORT} failed: {e}; retrying every second");
            }
            Err(_) => {}
        }
    }
}

struct Reply {
    code: u16,
    ctype: &'static str,
    body: Vec<u8>,
    /// "no-cache" for what the browser's AppCache keeps (page, manifest, images), else "no-store".
    cache: &'static str,
}

fn reply(code: u16, ctype: &'static str, body: impl Into<Vec<u8>>) -> Reply {
    Reply { code, ctype, body: body.into(), cache: "no-store" }
}

/// For the AppCache: revalidated on every load, so a new payload's page replaces the kept one.
fn cached(ctype: &'static str, body: impl Into<Vec<u8>>) -> Reply {
    Reply { cache: "no-cache", ..reply(200, ctype, body) }
}

/// The AppCache manifest: the tile's page opens offline (no payload yet) and starts the saved ELF.
/// Its comment changes with the version and the page, so a new build's page is fetched again.
fn appcache() -> String {
    let hash = UI.bytes().fold(0xcbf29ce484222325u64, |h, b| (h ^ b as u64).wrapping_mul(0x100000001b3));
    format!("CACHE MANIFEST\n# {} {hash:016x}\nCACHE:\n/\n/app-icon.png\nNETWORK:\n*\n", env!("CARGO_PKG_VERSION"))
}

fn no_content() -> Reply {
    reply(204, "", "")
}

fn not_found() -> Reply {
    reply(404, "text/plain", "not found")
}

/// A refused request: HTTP code, FreeBSD errno (the /api/v1 `status`) and the text.
#[derive(Debug, PartialEq)]
struct Fail {
    code: u16,
    errno: i32,
    msg: String,
}

fn fail(code: u16, errno: i32, msg: impl Into<String>) -> Fail {
    Fail { code, errno, msg: msg.into() }
}

impl Fail {
    /// The native routes' plain-text answer.
    fn text(self) -> Reply {
        reply(self.code, "text/plain", self.msg)
    }

    /// The /api/v1 answer (SMP API v1 shape).
    fn json(self) -> Reply {
        reply(self.code, "application/json", serde_json::json!({"status": self.errno, "error": self.msg}).to_string())
    }
}

/// A failed config::save as a Fail.
fn save_fail(e: std::io::Error) -> Fail {
    fail(500, e.raw_os_error().unwrap_or(libc::EIO), e.to_string())
}

/// Puts `item` into `list` (`on`) or takes it out; true when the list changed.
fn set_member(list: &mut Vec<String>, item: &str, on: bool) -> bool {
    let had = list.iter().any(|x| x == item);
    if on && !had {
        list.push(item.to_string());
    } else if !on && had {
        list.retain(|x| x != item);
    }
    on != had
}

/// An `exclude` entry as config.rs stores it: absolute, no trailing `/` (except "/" itself).
fn exclude_entry(path: &str) -> Option<String> {
    // A control character (newline, tab) does not survive config.toml's string syntax.
    if !path.starts_with('/') || path.chars().any(char::is_control) {
        return None;
    }
    let p = path.trim_end_matches('/');
    Some(if p.is_empty() { "/" } else { p }.to_string())
}

/// Changes the saved settings with `f` (on the file's copy: a scan pass may have put an older copy
/// into state.settings), held under the settings lock so a concurrent change is not lost. When `f`
/// reports a change: saves, applies and wakes the scan loop. Ok(changed); a save error is logged.
fn change_settings(state: &State, what: &str, f: impl FnOnce(&mut Settings) -> bool) -> std::io::Result<bool> {
    let mut cur = state.settings.lock().unwrap();
    let mut s = config::load();
    if !f(&mut s) {
        return Ok(false);
    }
    if let Err(e) = config::save(&s) {
        log!("{what}: save {}: {e}", config::CONFIG_PATH);
        return Err(e);
    }
    *cur = s;
    drop(cur);
    state.wake();
    Ok(true)
}

fn handle(state: &State, mut conn: TcpStream) -> std::io::Result<()> {
    conn.set_read_timeout(Some(Duration::from_secs(5)))?;
    conn.set_write_timeout(Some(Duration::from_secs(10)))?;
    let loopback = conn.peer_addr().map(|a| a.ip().is_loopback()).unwrap_or(false);
    let r = match read_request(&mut conn)? {
        Ok((head, body)) => route(state, &head, &body, loopback),
        Err(code) => reply(code, "text/plain", "bad or too large request"),
    };
    let reason = match r.code {
        200 => "OK",
        204 => "No Content",
        400 => "Bad Request",
        404 => "Not Found",
        409 => "Conflict",
        501 => "Not Implemented",
        413 => "Content Too Large",
        431 => "Request Header Fields Too Large",
        _ => "Error",
    };
    let mut head = format!("HTTP/1.1 {} {reason}\r\nConnection: close\r\n", r.code);
    if r.code != 204 {
        head += &format!("Content-Type: {}\r\nContent-Length: {}\r\n", r.ctype, r.body.len());
    }
    head += &format!("Cache-Control: {}\r\n\r\n", r.cache);
    conn.write_all(head.as_bytes())?;
    if r.code != 204 {
        conn.write_all(&r.body)?;
    }
    conn.flush()
}

/// Request line + headers, and the body by Content-Length; Err(status) when the head exceeds
/// MAX_REQUEST (431), the whole request would (413), or Content-Length is not a number (400).
fn read_request(conn: &mut TcpStream) -> std::io::Result<Result<(String, Vec<u8>), u16>> {
    let mut buf = Vec::with_capacity(1024);
    let mut chunk = [0u8; 2048];
    // (end of the head, end of the body)
    let mut need: Option<(usize, usize)> = None;
    loop {
        if need.is_none() {
            if let Some(end) = buf.windows(4).position(|w| w == b"\r\n\r\n") {
                let head = String::from_utf8_lossy(&buf[..end]).into_owned();
                let len = head.lines().find_map(|l| {
                    let (k, v) = l.split_once(':')?;
                    k.trim().eq_ignore_ascii_case("content-length").then(|| v.trim().parse::<usize>())
                });
                let len = match len {
                    None => 0,
                    Some(Ok(n)) => n,
                    Some(Err(_)) => return Ok(Err(400)),
                };
                // checked: a huge Content-Length must not wrap (panic=abort would end the payload).
                match (end + 4).checked_add(len) {
                    Some(n) if n <= MAX_REQUEST => need = Some((end, n)),
                    _ => return Ok(Err(413)),
                }
            }
        }
        match need {
            Some((end, n)) if buf.len() >= n => {
                let head = String::from_utf8_lossy(&buf[..end]).into_owned();
                return Ok(Ok((head, buf[end + 4..n].to_vec())));
            }
            None if buf.len() > MAX_REQUEST => return Ok(Err(431)),
            _ => {}
        }
        let n = conn.read(&mut chunk)?;
        if n == 0 {
            return Err(std::io::ErrorKind::UnexpectedEof.into());
        }
        buf.extend_from_slice(&chunk[..n]);
    }
}

fn route(state: &State, head: &str, body: &[u8], loopback: bool) -> Reply {
    let mut parts = head.lines().next().unwrap_or("").split(' ');
    let method = parts.next().unwrap_or("");
    let target = parts.next().unwrap_or("");
    let (path, query) = target.split_once('?').unwrap_or((target, ""));
    match (method, path) {
        ("GET", "/") => cached("text/html; charset=utf-8", UI.replace("__VERSION__", env!("CARGO_PKG_VERSION"))),
        ("GET", "/kraken.appcache") => cached("text/cache-manifest", appcache()),
        ("GET", "/app-icon.png") => cached("image/png", APP_ICON),
        ("GET", "/api/state") => reply(200, "application/json", api_state(state)),
        ("GET", p) if p.starts_with("/api/sizes/") => sizes(state, &p["/api/sizes/".len()..]),
        ("GET", p) if p.starts_with("/api/report/") => report(state, &p["/api/report/".len()..]),
        ("GET", "/api/settings") => {
            let v = config::to_json(&state.settings.lock().unwrap());
            reply(200, "application/json", v.to_string())
        }
        ("POST", "/api/settings") => post_settings(state, body),
        ("GET", "/api/ampr") => reply(200, "application/json", crate::ampr_status().to_string()),
        // The UI's "Update now": forced, one attempt, answered when done (one thread per request).
        ("POST", "/api/ampr/update") => match crate::ampr_update(state, true, 1) {
            Ok(m) => reply(200, "text/plain", m),
            Err(e) if e.contains("already running") => reply(409, "text/plain", e),
            Err(e) => reply(502, "text/plain", e),
        },
        ("POST", "/api/self_update") => self_update(state, body),
        // A newer copy taking over the port (loopback, empty body) or the UI's Shut down (body
        // "shutdown", from any host, as Dump Forge's Stop).
        ("POST", "/api/quit") if (loopback || body == b"shutdown") && state.paused() => {
            log!("quit refused: a game is running (its overlay would stay mounted)");
            reply(409, "text/plain", "a game is running")
        }
        ("POST", "/api/quit") if loopback || body == b"shutdown" => {
            let user = body == b"shutdown";
            // A newer copy waits for the scan pass: quitting mid-build would leave a cache without
            // `.built`, which the next start empties (game-written files included). Held until exit,
            // so no pass starts meanwhile.
            if !user {
                let Ok(work) = state.work.try_lock() else {
                    return reply(409, "text/plain", "a scan or build is in progress");
                };
                std::mem::forget(work);
            }
            let toast = user && state.settings.lock().unwrap().notify;
            log!("{}", if user { "shut down from the web UI" } else { "quit requested by a newer copy" });
            std::thread::spawn(move || {
                if toast {
                    sys::notify(crate::i18n::stopped(crate::i18n::lang()));
                }
                std::thread::sleep(Duration::from_millis(200));
                std::process::exit(0)
            });
            no_content()
        }
        ("POST", "/api/rescan") => {
            state.wake();
            no_content()
        }
        ("POST", "/api/rebuild-all") => {
            let tids = state.library();
            log!("rebuild of all {} games requested", tids.len());
            state.forced.lock().unwrap().extend(tids);
            state.wake();
            no_content()
        }
        ("POST", p) if p.starts_with("/api/playgo/") => post_playgo(state, &p["/api/playgo/".len()..], body),
        ("POST", p) if p.starts_with("/api/overlay/") => post_overlay(state, &p["/api/overlay/".len()..], body),
        ("POST", p) if p.starts_with("/api/v1/") => v1(state, &p["/api/v1/".len()..], body),
        ("POST", p) if p.starts_with("/api/rebuild/") => rebuild(state, &p["/api/rebuild/".len()..]),
        ("POST", p) if p.starts_with("/api/delete/") => delete(state, &p["/api/delete/".len()..], body),
        ("POST", p) if p.starts_with("/api/launch/") => launch(state, &p["/api/launch/".len()..]),
        ("POST", "/api/eject") => eject(state, body),
        ("POST", "/api/purge") => {
            log!("cache purge requested");
            state.purge.store(true, Ordering::SeqCst);
            state.wake();
            no_content()
        }
        ("GET", p) if p.starts_with("/icon/") => image(state, &p["/icon/".len()..], &["icon0.png"]),
        ("GET", p) if p.starts_with("/pic/") => image(state, &p["/pic/".len()..], &["pic0.png", "pic1.png"]),
        // Debug: read a file under /data (logs, klog.txt). Read-only.
        ("GET", p) if p.starts_with("/file/data/") && state.settings.lock().unwrap().debug => {
            dbg_file(&p["/file".len()..], query)
        }
        _ => not_found(),
    }
}

fn post_settings(state: &State, body: &[u8]) -> Reply {
    let parsed = serde_json::from_slice::<serde_json::Value>(body)
        .map_err(|e| format!("settings: {e}"))
        .and_then(|v| Ok((config::from_json(&v)?, v)));
    let (mut s, v) = match parsed {
        Ok(s) => s,
        Err(e) => {
            log!("settings rejected: {e}");
            return reply(400, "text/plain", e);
        }
    };
    if let Some(t) = s.overlay_off.iter().find(|t| state.source(t).is_some_and(|src| src.kind == Kind::Pkg)) {
        log!("settings rejected: {t}: overlay_off for a pkg game");
        return reply(409, "text/plain", format!("{t}: a pkg game needs its overlay"));
    }
    // Held across the save: a concurrent /api/playgo change is not lost.
    let mut cur = state.settings.lock().unwrap();
    // The settings form does not send the per-game lists nor `exclude`: keep them. From the file:
    // a scan pass may have put an older copy into state.settings.
    if ["playgo_off", "overlay_off", "exclude"].iter().any(|k| v.get(k).is_none()) {
        let file = config::load();
        if v.get("playgo_off").is_none() {
            s.playgo_off = file.playgo_off;
        }
        if v.get("overlay_off").is_none() {
            s.overlay_off = file.overlay_off;
        }
        if v.get("exclude").is_none() {
            s.exclude = file.exclude;
        }
    }
    if let Err(e) = config::save(&s) {
        log!("settings: save {}: {e}", config::CONFIG_PATH);
        return reply(500, "text/plain", e.to_string());
    }
    log!("settings saved");
    *cur = s;
    drop(cur);
    state.wake();
    no_content()
}

/// POST /api/self_update, body `{"version":"<tag>"}`: downloads the newer release found at start
/// and sends it to elfldr; the new copy then takes over the port. 200 `{}`, else update::install's code.
fn self_update(state: &State, body: &[u8]) -> Reply {
    let v: Option<serde_json::Value> = serde_json::from_slice(body).ok();
    let Some(version) = v.as_ref().and_then(|v| v["version"].as_str()) else {
        return reply(400, "text/plain", "expected {\"version\":\"<tag>\"}");
    };
    // The new copy's quit waits for the pass and take_port gives up after 5 s: install holds off new
    // passes (update::holding) and checks that none runs.
    match crate::update::install(version, &|| state.paused(), &|| state.work.try_lock().is_ok()) {
        Ok(()) => reply(200, "application/json", "{}"),
        Err((code, e)) => reply(code, "text/plain", e),
    }
}

/// POST /api/playgo/<TID>, body `on` or `off`: the bundled PlayGo stub for one game (playgo_off).
fn post_playgo(state: &State, tid: &str, body: &[u8]) -> Reply {
    if !crate::scan::valid_tid(tid) || state.source(tid).is_none() {
        return not_found();
    }
    let off = match body {
        b"on" => false,
        b"off" => true,
        _ => return reply(400, "text/plain", "expected on or off"),
    };
    if let Err(e) = change_settings(state, &format!("{tid}: PlayGo stub"), |s| set_member(&mut s.playgo_off, tid, off)) {
        return reply(500, "text/plain", e.to_string());
    }
    log!("{tid}: PlayGo stub {}", if off { "off" } else { "on" });
    no_content()
}

/// The fakelib overlay of one library title on (`off` false) or off (overlay_off). Off is refused
/// for a pkg: it needs ampr-emu-ng's pkg mode.
fn set_overlay(state: &State, tid: &str, off: bool) -> Result<(), Fail> {
    let Some(src) = Some(tid).filter(|t| crate::scan::valid_tid(t)).and_then(|t| state.source(t)) else {
        return Err(fail(404, libc::ENOENT, "not found"));
    };
    if off && src.kind == Kind::Pkg {
        log!("{tid}: overlay off refused: {} is a pkg (needs ampr-emu-ng's pkg mode)", src.path.display());
        return Err(fail(409, libc::EPERM, "a pkg game needs its overlay (ampr-emu-ng's pkg mode)"));
    }
    if change_settings(state, &format!("{tid}: overlay"), |s| set_member(&mut s.overlay_off, tid, off)).map_err(save_fail)? {
        log!("{tid}: overlay {}", if off { "off" } else { "on" });
    }
    Ok(())
}

/// POST /api/overlay/<TID>, body `on` or `off`.
fn post_overlay(state: &State, tid: &str, body: &[u8]) -> Reply {
    let off = match body {
        b"on" => false,
        b"off" => true,
        _ if !crate::scan::valid_tid(tid) || state.source(tid).is_none() => return not_found(),
        _ => return reply(400, "text/plain", "expected on or off"),
    };
    match set_overlay(state, tid, off) {
        Ok(()) => no_content(),
        Err(f) => f.text(),
    }
}

/// Serves an absolute path under /data (no traversal above /data). Whole file: first 256 KiB as
/// text. With ?off=N&len=M: those bytes (M <= 16 MiB) as octet-stream, read in place, so large
/// files can be pulled in pieces.
fn dbg_file(path: &str, query: &str) -> Reply {
    use std::os::unix::fs::FileExt;
    if path.contains("..") {
        return not_found();
    }
    let arg = |k: &str| {
        query.split('&').find_map(|kv| kv.strip_prefix(k)?.strip_prefix('=')?.parse::<u64>().ok())
    };
    if let (Some(off), Some(len)) = (arg("off"), arg("len")) {
        let Ok(f) = std::fs::File::open(path) else { return not_found() };
        let mut buf = vec![0u8; len.min(16 << 20) as usize];
        let mut n = 0;
        while n < buf.len() {
            match f.read_at(&mut buf[n..], off + n as u64) {
                Ok(0) => break,
                Ok(k) => n += k,
                Err(_) => return not_found(),
            }
        }
        buf.truncate(n);
        return reply(200, "application/octet-stream", buf);
    }
    match std::fs::read(path) {
        Ok(mut b) => {
            b.truncate(256 * 1024);
            reply(200, "text/plain; charset=utf-8", b)
        }
        Err(_) => not_found(),
    }
}

/// kraken.log lines (with the title id) at the end of a game's report.
const REPORT_LOG_LINES: usize = 40;

/// GET /api/report/<TID>: plain text to paste into an issue; 404 for an invalid or absent library title.
fn report(state: &State, tid: &str) -> Reply {
    if !crate::scan::valid_tid(tid) {
        return not_found();
    }
    let Some(g) = state.games.lock().unwrap().iter().find(|g| g.src.title_id == tid && g.status != "duplicate").cloned()
    else {
        return not_found();
    };
    let s = state.settings.lock().unwrap().clone();
    let ampr = crate::ampr_status();
    let crash = crate::crash::load().remove(tid);
    let log = log_tail();
    let log = String::from_utf8_lossy(&log);
    reply(200, "text/plain; charset=utf-8", report_text(&g, &s, &ampr, crash.as_ref(), &log))
}

fn report_text(g: &Game, s: &Settings, ampr: &serde_json::Value, crash: Option<&crate::crash::Crash>, log: &str) -> String {
    let src = &g.src;
    let kind = match src.kind {
        Kind::Pkg => "pkg",
        Kind::Folder(Packing::Plain) => "folder",
        Kind::Folder(Packing::Zstd) => "folder (zstd)",
        Kind::Folder(Packing::Lz4) => "folder (lz4)",
    };
    let ampr = format!("{} {}", ampr["kind"].as_str().unwrap_or("?"), ampr["version"].as_str().unwrap_or("")).trim_end().to_string();
    let playgo = if !s.add_emulators { "not added (add_emulators off)" }
        else if s.playgo_off.iter().any(|t| *t == src.title_id) { "off" } else { "on" };
    let crash = crash.map_or("none recorded".to_string(), |c| {
        format!("{} in {}, {} (console dump folder {})", sys::utc(c.at as libc::time_t), c.process, c.status, c.folder)
    });
    let mut out = format!(
        "Kraken Mount {}\nFirmware: (please fill in)\nGame: {} ({}), version {}\nSource: {} ({kind}, {})\n\
         Status: {}{}\nampr-emu-ng: {ampr}\nPlayGo stub: {playgo}\nLast crash: {crash}\n",
        env!("CARGO_PKG_VERSION"), src.title_name, src.title_id, src.version, src.path.display(), src.drive,
        g.status, g.error.as_deref().map_or(String::new(), |e| format!(" ({e})")),
    );
    let lines: Vec<&str> = log.lines().filter(|l| l.contains(src.title_id.as_str())).collect();
    out += &format!("\nkraken.log, last {} lines with {}:\n", REPORT_LOG_LINES, src.title_id);
    for l in &lines[lines.len().saturating_sub(REPORT_LOG_LINES)..] {
        out += l;
        out.push('\n');
    }
    out
}

fn api_state(state: &State) -> Vec<u8> {
    let playgo_off = {
        let s = state.settings.lock().unwrap();
        s.add_emulators.then(|| s.playgo_off.clone())
    };
    let overlay_off = state.settings.lock().unwrap().overlay_off.clone();
    let crashes = crate::crash::load();
    // A rebuild asked for but not started yet (the pass picks it up, or a game is running).
    let queued = state.forced.lock().unwrap().clone();
    // A copy: presence reads app.db, the mount table and the sources without holding the lock.
    let games = state.games.lock().unwrap().clone();
    let games: Vec<_> = games.iter().zip(presence(&games)).map(|(g, [registered, mounted, present])| {
        let mut v = game_json(g, playgo_off.as_deref(), crashes.get(&g.src.title_id));
        v["rebuild_queued"] = queued.contains(&g.src.title_id).into();
        v["registered"] = registered.into();
        v["mounted"] = mounted.into();
        v["source_present"] = present.into();
        // As cache.rs: a pkg source keeps its fakelib whatever overlay_off says.
        v["overlay_off"] = (g.src.kind != Kind::Pkg && overlay_off.contains(&g.src.title_id)).into();
        v
    }).collect();
    let all = storage::drives();
    let drives: Vec<_> = all
        .iter()
        .map(|d| serde_json::json!({"mount": d.mount, "label": d.label, "kind": d.kind, "total": d.total, "free": d.free,
            "ejectable": storage::ejectable(&d.mount)}))
        .collect();
    let free = all.iter().find(|d| d.mount == "/data").map_or(0, |d| d.free);
    let log = log_tail();
    let log = String::from_utf8_lossy(&log);
    let lines: Vec<&str> = log.lines().collect();
    let tail = &lines[lines.len().saturating_sub(LOG_LINES)..];
    let mut running: Vec<String> = state.running.lock().unwrap().iter().cloned().collect();
    running.sort();
    let v = serde_json::json!({
        "version": env!("CARGO_PKG_VERSION"),
        "update": crate::update::available(),
        "busy": state.busy.load(Ordering::SeqCst),
        "paused": !running.is_empty(),
        "waiting": *state.waiting.lock().unwrap(),
        "running": running,
        "games": games,
        "drives": drives,
        "cache": {
            "path": cache::CACHES,
            "size": *state.cache_total.lock().unwrap(),
            "free": free,
            "low_space": state.low_space.load(Ordering::SeqCst),
            "ampr_present": Path::new(cache::AMPR_DIR).join("libSceAmpr.sprx").is_file(),
        },
        "log": tail,
    });
    v.to_string().into_bytes()
}

/// Per game: [registered, mounted (/system_ex/app/<TID> is a mount point), source present], from
/// one app.db read and one mount table for all of them.
fn presence(games: &[Game]) -> Vec<[bool; 3]> {
    let tids: Vec<&str> = games.iter().map(|g| g.src.title_id.as_str()).collect();
    let registered = register::registered(&tids);
    static FAILED: AtomicBool = AtomicBool::new(false);
    let mounts: HashSet<String> = match mount_table() {
        Ok(m) => {
            FAILED.store(false, Ordering::Relaxed);
            m.into_iter().map(|(on, _, _)| on).collect()
        }
        Err(e) => {
            // Once until it reads again: /api/state polls this every second or two per open UI.
            if !FAILED.swap(true, Ordering::Relaxed) {
                log!("title status: getfsstat: {e}; titles shown as not mounted");
            }
            HashSet::new()
        }
    };
    games.iter().zip(registered).map(|(g, registered)| {
        [registered, mounts.contains(&format!("/system_ex/app/{}", g.src.title_id)), g.src.path.exists()]
    }).collect()
}

/// The last LOG_TAIL bytes of kraken.log (sys.rs rotates it at ~4 MiB), from a line start.
fn log_tail() -> Vec<u8> {
    use std::io::{Seek, SeekFrom};
    const LOG_TAIL: u64 = 64 << 10;
    let Ok(mut f) = std::fs::File::open(sys::LOG_PATH) else { return Vec::new() };
    let len = f.metadata().map_or(0, |m| m.len());
    let off = len.saturating_sub(LOG_TAIL);
    let mut b = Vec::new();
    if f.seek(SeekFrom::Start(off)).is_err() || f.take(LOG_TAIL).read_to_end(&mut b).is_err() {
        return Vec::new();
    }
    if off > 0 {
        let cut = b.iter().position(|&c| c == b'\n').map_or(b.len(), |i| i + 1);
        b.drain(..cut);
    }
    b
}

fn rebuild(state: &State, tid: &str) -> Reply {
    if !crate::scan::valid_tid(tid) || state.source(tid).is_none() {
        return not_found();
    }
    log!("{tid}: rebuild requested");
    state.forced.lock().unwrap().insert(tid.to_string());
    state.wake();
    no_content()
}

fn sizes(state: &State, tid: &str) -> Reply {
    if !crate::scan::valid_tid(tid) {
        return not_found();
    }
    let Some(src) = state.source(tid) else { return not_found() };
    let game = match src.kind {
        Kind::Pkg => fs::metadata(&src.path).map(|m| m.len()).unwrap_or_else(|e| {
            log!("{tid}: stat {}: {e}", src.path.display());
            src.size
        }),
        Kind::Folder(_) => cache::du(&src.path),
    };
    let dlc: u64 = [
        "/user/addcont", "/mnt/ext0/user/addcont", "/mnt/ext0/ps5/user/addcont",
        "/mnt/ext1/user/addcont", "/mnt/ext1/ps5/user/addcont",
    ].iter().map(|root| cache::du(&Path::new(root).join(tid))).sum();
    let family = if tid.starts_with("PPSA") { "savedata_prospero" } else { "savedata" };
    let save = match fs::read_dir("/user/home") {
        Ok(entries) => {
            let mut total = 0;
            let mut failed = false;
            for entry in entries {
                match entry.and_then(|e| Ok((e.file_name(), e.file_type()?, e.path()))) {
                    Ok((name, ty, home)) => {
                        let name = name.to_string_lossy();
                        if ty.is_dir() && name.len() == 8 && name.bytes().all(|b| b.is_ascii_hexdigit()) {
                            total += cache::du(&home.join(family).join(tid));
                        }
                    }
                    Err(e) => {
                        log!("{tid}: read /user/home: {e}");
                        failed = true;
                        break;
                    }
                }
            }
            if failed { None } else { Some(total) }
        }
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Some(0),
        Err(e) => {
            log!("{tid}: read /user/home: {e}");
            None
        }
    };
    reply(200, "application/json", serde_json::json!({
        "game": game, "dlc": dlc, "save": save, "cache": cache::size(tid),
    }).to_string())
}

fn safe_delete_source(src: &Source, roots: &[String]) -> Result<(), &'static str> {
    let path = &src.path;
    if !path.is_absolute() || path.components().any(|c| c == Component::ParentDir) {
        return Err("source path is not a safe absolute path");
    }
    if ["/", "/data", "/user", "/mnt", "/system", "/system_ex"].iter().any(|p| path == Path::new(p))
        || path.parent() == Some(Path::new("/mnt"))
        || storage::drives().iter().any(|d| path == Path::new(&d.mount)) {
        return Err("source path is a protected root");
    }
    let roots: Vec<&Path> = roots.iter().map(|r| {
        let trimmed = r.trim_end_matches('/');
        Path::new(if trimmed.is_empty() { "/" } else { trimmed })
    }).collect();
    if roots.iter().any(|root| path == *root || root.starts_with(path)) {
        return Err("source path is a scan root or its parent");
    }
    let Some(root) = roots.iter().filter(|root| path.starts_with(root)).max_by_key(|r| r.as_os_str().len()) else {
        return Err("source path is outside scan roots");
    };
    // No symlink from the scan root down to the source: the path text must be where it lives.
    // ponytail: links above the root are not checked (system paths may be links; the root is the user's choice).
    // ponytail: checked once; a link swapped in before remove_dir_all is not caught (std does not follow it).
    if path.ancestors().skip(1).take_while(|a| a.starts_with(root))
        .any(|a| fs::symlink_metadata(a).map(|m| m.file_type().is_symlink()).unwrap_or(true)) {
        return Err("source path goes through a symlink");
    }
    let meta = fs::symlink_metadata(path).map_err(|_| "source path is missing or inaccessible")?;
    match src.kind {
        Kind::Pkg if meta.is_file() && path.extension().is_some_and(|e| e.eq_ignore_ascii_case("pkg")) => Ok(()),
        Kind::Folder(_) if meta.is_dir() => Ok(()),
        Kind::Pkg => Err("source is not a .pkg file"),
        Kind::Folder(_) => Err("source is not a directory"),
    }
}

/// Starts a ready library title, as its home screen tile does.
fn launch(state: &State, tid: &str) -> Reply {
    if !crate::scan::valid_tid(tid) {
        return not_found();
    }
    let status = state.games.lock().unwrap().iter()
        .find(|g| g.src.title_id == tid && g.status != "duplicate").map(|g| g.status);
    let Some(status) = status else { return not_found() };
    if state.paused() {
        return reply(409, "text/plain", "a game is running");
    }
    if status != "ready" {
        return reply(409, "text/plain", "the game is not ready");
    }
    match sys::launch_app(tid) {
        Ok(()) => no_content(),
        Err(e) => {
            log!("{tid}: launch: {e}");
            reply(502, "text/plain", e)
        }
    }
}

/// The guards of delete and uninstall: `work` (the scan loop holds it while it scans, builds or
/// registers; never wait a build out here), a library title, no game running, the title not building.
fn lock_title<'a>(state: &'a State, tid: &str) -> Result<(std::sync::MutexGuard<'a, ()>, Source), Fail> {
    if !crate::scan::valid_tid(tid) {
        return Err(fail(404, libc::ENOENT, "not found"));
    }
    let Ok(work) = state.work.try_lock() else {
        return Err(fail(409, libc::EBUSY, "a scan or build is in progress; try again in a moment"));
    };
    let Some(src) = state.source(tid) else { return Err(fail(404, libc::ENOENT, "not found")) };
    if state.paused() || state.running.lock().unwrap().contains(tid) {
        return Err(fail(409, libc::EBUSY, "a game is running"));
    }
    if state.games.lock().unwrap().iter().any(|g| g.src.title_id == tid && matches!(g.status, "building" | "checking")) {
        return Err(fail(409, libc::EBUSY, "the game is being built"));
    }
    Ok((work, src))
}

fn delete(state: &State, tid: &str, body: &[u8]) -> Reply {
    let (_work, src) = match lock_title(state, tid) {
        Ok(x) => x,
        Err(f) => return f.text(),
    };
    // The UI sends the path it showed in the confirmation; a scan may have picked another copy since.
    if body != src.path.as_os_str().as_encoded_bytes() {
        log!("{tid}: delete refused: asked for {:?}, library source is {}", String::from_utf8_lossy(body), src.path.display());
        return reply(409, "text/plain", "the library changed; reopen the game and try again");
    }
    let roots = {
        let settings = state.settings.lock().unwrap();
        if settings.scan_paths.is_empty() { storage::default_scan_roots() } else { settings.scan_paths.clone() }
    };
    if let Err(reason) = safe_delete_source(&src, &roots) {
        log!("{tid}: delete rejected {}: {reason}", src.path.display());
        return reply(409, "text/plain", reason);
    }
    if let Err(e) = register::unmount_title(tid) {
        log!("{tid}: unmount {}: {e}", src.path.display());
        return reply(409, "text/plain", e.to_string());
    }
    // Source first: if it cannot be removed, the cache (game-written files) and the tile stay.
    let result = match src.kind {
        Kind::Pkg => fs::remove_file(&src.path),
        Kind::Folder(_) => fs::remove_dir_all(&src.path),
    };
    if let Err(e) = result {
        log!("{tid}: delete source {}: {e}", src.path.display());
        // Unmounted above: the next pass remounts it (process: register::mount on a registered title).
        // ponytail: a folder remove_dir_all that failed midway leaves a partial source; not restored.
        state.wake();
        return reply(500, "text/plain", e.to_string());
    }
    if let Err(e) = register::uninstall(tid) {
        // ponytail: the tile may stay; the next scan does not re-register a deleted source.
        log!("{tid}: uninstall {}: {e}", src.path.display());
    }
    state.titles.lock().unwrap().remove(tid);
    state.games.lock().unwrap().retain(|g| g.src.path != src.path);
    state.wake();
    let cache_dir = cache::dir(tid);
    if cache_dir.exists() {
        if let Err(e) = fs::remove_dir_all(&cache_dir) {
            log!("{tid}: delete cache {}: {e}", cache_dir.display());
            return reply(500, "text/plain", format!("source deleted; cache not: {e}"));
        }
    }
    log!("{tid}: deleted {}", src.path.display());
    if state.settings.lock().unwrap().notify {
        sys::notify(&crate::i18n::deleted(crate::i18n::lang(), &src.title_name));
    }
    no_content()
}

/// /api/v1/manual/remove (`exclude` true) or add: Kraken Mount sees every folder in its scan roots,
/// so removing a manual source means excluding it, adding one takes it off `exclude`. Idempotent.
fn manual(state: &State, b: &Obj, exclude: bool) -> Result<serde_json::Value, Fail> {
    let path = str_field(b, "path")?;
    let Some(entry) = exclude_entry(path) else {
        return Err(fail(400, libc::EINVAL, "path: expected an absolute path"));
    };
    let changed = change_settings(state, &format!("exclude {entry}"), |s| set_member(&mut s.exclude, &entry, exclude))
        .map_err(save_fail)?;
    if changed {
        log!("{entry}: {} the excluded paths from the web API", if exclude { "added to" } else { "removed from" });
    }
    Ok(serde_json::json!({"changed": changed}))
}

/// /api/v1/games/uninstall: off the home screen and unmounted; the source is excluded so the next
/// scan leaves it alone. Never deletes the source or the cache (game-written files stay).
fn uninstall_keep(state: &State, tid: &str) -> Result<serde_json::Value, Fail> {
    let (_work, src) = lock_title(state, tid)?;
    let path = src.path.to_string_lossy().into_owned();
    // As auto-remove: an installed copy of this title id (or one we did not stage) is never uninstalled.
    if let Err(p) = register::is_ours(tid) {
        log!("{tid}: uninstall refused: {} is not a Kraken Mount registration", p.display());
        return Err(fail(409, libc::EPERM, format!("{} is not a Kraken Mount registration", p.display())));
    }
    if let Err(e) = register::unmount_title(tid) {
        log!("{tid}: unmount {path}: {e}");
        return Err(fail(409, libc::EBUSY, e.to_string()));
    }
    // ponytail: a non-UTF-8 source path is excluded by its lossy text, which then matches nothing.
    let Some(entry) = exclude_entry(&path) else {
        log!("{tid}: uninstall refused: {path} is not an absolute path");
        state.wake();
        return Err(fail(409, libc::EINVAL, "the source path is not absolute"));
    };
    // Every copy of the title (duplicates too): otherwise the next scan picks a duplicate as the
    // winner and registers the title again.
    // ponytail: only the listed copies; one still being copied (scan's `unstable`) is not known here.
    let mut entries = vec![entry];
    let others: Vec<PathBuf> = state.games.lock().unwrap().iter()
        .filter(|g| g.src.title_id == tid && g.src.path != src.path).map(|g| g.src.path.clone()).collect();
    for p in &others {
        match exclude_entry(&p.to_string_lossy()) {
            Some(e) if !entries.contains(&e) => entries.push(e),
            Some(_) => {}
            None => log!("{tid}: duplicate {} is not an absolute path: not excluded", p.display()),
        }
    }
    let what = format!("{tid}: exclude {}", entries.join(", "));
    // Excluded first, so a failed save leaves the title registered and untouched (the next pass
    // remounts it); a failed uninstall takes back what this call added, so the next pass remounts
    // the title that is still on the home screen and the caller can retry.
    let mut added = Vec::new();
    let change = change_settings(state, &what, |s| {
        added = entries.iter().filter(|e| set_member(&mut s.exclude, e, true)).cloned().collect();
        !added.is_empty()
    });
    if let Err(e) = change {
        state.wake();
        return Err(save_fail(e));
    }
    if let Err(e) = register::uninstall(tid) {
        log!("{tid}: uninstall {path}: {e}");
        let mut msg = e.to_string();
        let undo = |s: &mut Settings| added.iter().fold(false, |c, e| set_member(&mut s.exclude, e, false) | c);
        if !added.is_empty() && change_settings(state, &what, undo).is_err() {
            msg += &format!("; {} stay excluded (config save failed): take them off with manual/add", added.join(", "));
        }
        state.wake();
        return Err(fail(500, libc::EIO, msg));
    }
    register::forget(tid);
    state.titles.lock().unwrap().remove(tid);
    state.games.lock().unwrap().retain(|g| g.src.title_id != tid);
    state.wake();
    log!("{tid}: uninstalled from the web API, {path} kept and excluded");
    Ok(serde_json::json!({}))
}

type Obj = serde_json::Map<String, serde_json::Value>;

/// An /api/v1 request body: one JSON object; an empty body is {}.
fn v1_body(body: &[u8]) -> Result<Obj, Fail> {
    if body.iter().all(u8::is_ascii_whitespace) {
        return Ok(Obj::new());
    }
    match serde_json::from_slice(body) {
        Ok(serde_json::Value::Object(o)) => Ok(o),
        Ok(_) => Err(fail(400, libc::EINVAL, "expected a JSON object")),
        Err(e) => Err(fail(400, libc::EINVAL, format!("bad JSON: {e}"))),
    }
}

fn str_field<'a>(b: &'a Obj, key: &str) -> Result<&'a str, Fail> {
    b.get(key).and_then(|v| v.as_str()).ok_or_else(|| fail(400, libc::EINVAL, format!("{key}: expected a string")))
}

/// /api/v1/games/fakelib: true = overlay off. `mode` ("disabled", "full" or "default"; "emulators"
/// is not supported) wins over `ignore_global_fakelib` (true = off).
fn fakelib_off(b: &Obj) -> Result<bool, Fail> {
    match (b.get("mode"), b.get("ignore_global_fakelib")) {
        (Some(m), _) => match m.as_str() {
            Some("disabled") => Ok(true),
            Some("full" | "default") => Ok(false),
            Some("emulators") => Err(fail(501, libc::ENOTSUP, "mode emulators is not supported")),
            _ => Err(fail(400, libc::EINVAL, "mode: expected full, default or disabled")),
        },
        (None, Some(v)) => v.as_bool().ok_or_else(|| fail(400, libc::EINVAL, "ignore_global_fakelib: expected a boolean")),
        (None, None) => Err(fail(400, libc::EINVAL, "expected mode or ignore_global_fakelib")),
    }
}

/// POST /api/v1/<route>: the ShadowMount+ API v1 subset Playden calls (DESIGN.md "Web API").
fn v1(state: &State, route: &str, body: &[u8]) -> Reply {
    use serde_json::json;
    let r = v1_body(body).and_then(|b| match route {
        "version" => Ok(json!({
            "api_version": 1,
            "kraken_mount_version": env!("CARGO_PKG_VERSION"),
            "capabilities": ["list_games", "add_manual_source", "remove_manual_source", "uninstall_game", "rescan", "fakelib"],
        })),
        "games" => Ok(v1_games(state)),
        "scan" => {
            state.wake();
            Ok(json!({}))
        }
        "manual/add" => manual(state, &b, false),
        "manual/remove" => manual(state, &b, true),
        "games/uninstall" => uninstall_keep(state, str_field(&b, "title_id")?),
        "games/fakelib" => {
            let tid = str_field(&b, "title_id")?;
            let off = fakelib_off(&b)?;
            set_overlay(state, tid, off)?;
            Ok(json!({"fakelib_mode": if off { "disabled" } else { "full" }, "saved": true, "applies_on_next_launch": true}))
        }
        _ => Err(fail(404, libc::ENOENT, "unknown route")),
    });
    match r {
        Ok(mut v) => {
            v["status"] = 0.into();
            reply(200, "application/json", v.to_string())
        }
        Err(f) => f.json(),
    }
}

/// Library titles (no duplicates) in SMP's games shape.
fn v1_games(state: &State) -> serde_json::Value {
    let games: Vec<Game> = state.games.lock().unwrap().iter().filter(|g| g.status != "duplicate").cloned().collect();
    let overlay_off = state.settings.lock().unwrap().overlay_off.clone();
    let list: Vec<_> = games.iter().zip(presence(&games)).map(|(g, [registered, mounted, present])| {
        let path = g.src.path.to_string_lossy();
        let folder = matches!(g.src.kind, Kind::Folder(_));
        serde_json::json!({
            "title_id": g.src.title_id,
            "name": g.src.title_name,
            "version": g.src.version,
            "path": path,
            "runtime_path": if folder { &path[..] } else { "" },
            "source_type": if folder { "folder" } else { "pkg" },
            "managed": true,
            "installed": registered,
            "mounted": mounted,
            "source_available": present,
            "status": g.status,
            "error": g.error.as_deref().unwrap_or(""),
            // As cache.rs: a pkg source keeps its fakelib whatever overlay_off says.
            "fakelib_mode": if folder && overlay_off.contains(&g.src.title_id) { "disabled" } else { "full" },
        })
    }).collect();
    serde_json::json!({"count": list.len(), "games": list})
}

// Lives in ps5/usb.c (IPMI to SceAutoMounterIpc, SMP sm_usb.c port).
extern "C" {
    fn km_usb_eject(path: *const libc::c_char, source: *const libc::c_char, fsid: u64, native_status: *mut i32) -> i32;
}

/// (mount point, source, fsid) of every mount. getfsstat into our own buffer: ps5/compat.c's
/// getmntinfo shares one static buffer with the launch watcher's thread.
fn mount_table() -> std::io::Result<Vec<(String, String, u64)>> {
    let mut extra = 8; // room for mounts added between the two calls
    for _ in 0..4 {
        let n = unsafe { libc::getfsstat(std::ptr::null_mut(), 0, libc::MNT_NOWAIT) };
        if n < 0 {
            return Err(std::io::Error::last_os_error());
        }
        let mut buf: Vec<libc::statfs> = vec![unsafe { std::mem::zeroed() }; n as usize + extra];
        let bytes = (buf.len() * std::mem::size_of::<libc::statfs>()) as libc::c_long;
        let n = unsafe { libc::getfsstat(buf.as_mut_ptr(), bytes, libc::MNT_NOWAIT) };
        if n < 0 {
            return Err(std::io::Error::last_os_error());
        }
        // A full buffer may be a cut table: the dependency checks need every mount.
        if (n as usize) < buf.len() {
            return Ok(buf[..n as usize].iter().map(mount_entry).collect());
        }
        extra *= 4;
    }
    Err(std::io::Error::other("the mount table kept growing"))
}

fn mount_entry(fs: &libc::statfs) -> (String, String, u64) {
    // SMP sm_usb_filesystem_id: the 8-byte fsid as one u64.
    let fsid = unsafe { std::mem::transmute::<libc::fsid_t, u64>(fs.f_fsid) };
    // Bounded: a name that fills its field has no NUL.
    (crate::launch::c_field(&fs.f_mntonname), crate::launch::c_field(&fs.f_mntfromname), fsid)
}

/// The mount exactly at `path`: Ok(None) when the path resolves to its parent FS (an unmounted
/// /mnt/usbN reports /mnt) or is gone (ENOENT); any other statfs error is Err (SMP sm_usb_check_mount).
fn mount_at(path: &str) -> std::io::Result<Option<(String, String, u64)>> {
    let c = std::ffi::CString::new(path).map_err(|_| std::io::Error::from_raw_os_error(libc::EINVAL))?;
    let mut fs: libc::statfs = unsafe { std::mem::zeroed() };
    if unsafe { libc::statfs(c.as_ptr(), &mut fs) } != 0 {
        let e = std::io::Error::last_os_error();
        return if e.raw_os_error() == Some(libc::ENOENT) { Ok(None) } else { Err(e) };
    }
    Ok(Some(mount_entry(&fs)).filter(|m| m.0 == path))
}

/// SMP usb_disk_source_length: the length of "/dev/daN" when followed by the end, 'p' or 's'.
fn disk_len(source: &str) -> usize {
    let Some(rest) = source.strip_prefix("/dev/da") else { return 0 };
    let digits = rest.bytes().take_while(u8::is_ascii_digit).count();
    if digits == 0 {
        return 0;
    }
    match rest.as_bytes().get(digits) {
        None | Some(b'p' | b's') => 7 + digits,
        _ => 0,
    }
}

/// POST /api/eject: unmounts our titles on the drive, then asks the system to eject it (SMP
/// run_usb_eject_job). `work` is held throughout so the scan loop cannot remount meanwhile.
fn eject(state: &State, body: &[u8]) -> Reply {
    let path = String::from_utf8_lossy(body).into_owned();
    if !storage::ejectable(&path) {
        return reply(400, "text/plain", "not an ejectable drive");
    }
    let (source, fsid) = match mount_at(&path) {
        Ok(Some((_, source, fsid))) => (source, fsid),
        Ok(None) => return reply(404, "text/plain", "the drive is not mounted"),
        Err(e) => {
            log!("eject {path}: statfs: {e}");
            return reply(500, "text/plain", format!("cannot read the drive: {e}"));
        }
    };
    let Ok(work) = state.work.try_lock() else {
        return reply(409, "text/plain", "a scan or build is in progress; try again in a moment");
    };
    if state.paused() {
        return reply(409, "text/plain", "a game is running");
    }
    // ponytail: the drive's identity is taken now, not when the page was drawn; a drive swapped in
    // between is ejected. Harmless: it is only an unmount.
    // An unreadable table fails closed: the dependency checks below need it.
    let mounts = match mount_table() {
        Ok(m) => m,
        Err(e) => {
            log!("eject {path}: getfsstat: {e}");
            return reply(500, "text/plain", format!("cannot read the mount table: {e}"));
        }
    };
    let disk = disk_len(&source);
    let other = mounts.iter().find(|(on, from, _)| {
        *on != path && disk != 0 && disk_len(from) == disk && from[..disk] == source[..disk]
    });
    if let Some((on, from, _)) = other {
        log!("eject {path}: another partition of the drive is mounted: {on} ({from})");
        return reply(409, "text/plain", format!("another partition of this drive is mounted: {on}"));
    }
    let mut tids: Vec<&str> = mounts
        .iter()
        .filter_map(|(on, from, _)| {
            let tid = on.strip_prefix("/system_ex/app/").filter(|t| crate::scan::valid_tid(t))?;
            let from = from.strip_prefix("<above>:").unwrap_or(from);
            (from == path || from.starts_with(&format!("{path}/"))).then_some(tid)
        })
        .collect();
    tids.sort_unstable();
    tids.dedup();
    for tid in tids {
        if let Err(e) = register::unmount_title(tid) {
            log!("eject {path}: {tid}: unmount: {e}");
            drop(work);
            state.wake();
            return reply(409, "text/plain", e.to_string());
        }
    }
    // The launch watcher does not take `work`: a game may have started since the check above (SMP
    // rechecks too). ponytail: a game starting between here and the IPMI call is not caught; its
    // sandbox's /mnt/usbN alias then keeps the drive busy or goes with it.
    let result = if state.paused() {
        log!("eject {path}: a game started; not ejected");
        reply(409, "text/plain", "a game is running")
    } else {
        eject_and_confirm(&path, &source, fsid)
    };
    drop(work);
    // The next pass forgets the gone drive's games; on failure it remounts the titles unmounted above.
    state.wake();
    result
}

fn eject_and_confirm(path: &str, source: &str, fsid: u64) -> Reply {
    let (Ok(cpath), Ok(csource)) = (std::ffi::CString::new(path), std::ffi::CString::new(source)) else {
        return reply(400, "text/plain", "NUL in the path");
    };
    let mut native = 0i32;
    let rc = unsafe { km_usb_eject(cpath.as_ptr(), csource.as_ptr(), fsid, &mut native) };
    if rc == libc::ENOENT || rc == libc::ESTALE {
        log!("eject {path}: the mount changed (errno {rc})");
        return reply(409, "text/plain", "the drive changed; refresh and try again");
    }
    if rc != 0 {
        log!("eject {path}: failed: errno {rc}, native status {:#010x}", native as u32);
        return reply(502, "text/plain", format!("eject failed: errno {rc}, native status {:#010x}", native as u32));
    }
    for _ in 0..50 {
        // Only a seen unmount counts; a statfs error keeps polling (SMP: unconfirmed).
        if let Ok(None) = mount_at(path) {
            log!("eject {path}: done ({source})");
            return no_content();
        }
        std::thread::sleep(Duration::from_millis(100));
    }
    log!("eject {path}: requested, but still mounted after 5 s");
    reply(502, "text/plain", "unmount not confirmed; keep the drive connected and refresh")
}

/// The first of `names` in the source's sce_sys, else in /user/appmeta/<TID>/, else (a pkg) in the .pkg.
fn image(state: &State, tid: &str, names: &[&str]) -> Reply {
    if !crate::scan::valid_tid(tid) {
        return not_found();
    }
    let src = state.source(tid);
    let mut dirs: Vec<PathBuf> = src.iter().map(cache::sce_sys).collect();
    dirs.push(Path::new("/user/appmeta").join(tid));
    for dir in &dirs {
        for name in names {
            if let Ok(png) = std::fs::read(dir.join(name)) {
                return reply(200, "image/png", png);
            }
        }
    }
    // A pkg whose cache is not built (yet, or it failed): straight from the .pkg.
    if let Some(src) = src.filter(|s| s.kind == Kind::Pkg) {
        for name in names {
            match cache::pkg_file(&src.path, &format!("sce_sys/{name}")) {
                Ok(png) => return reply(200, "image/png", png),
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
                Err(e) => log!("{tid}: image {name} from {}: {e}", src.path.display()),
            }
        }
    }
    not_found()
}
